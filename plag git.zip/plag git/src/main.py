from flask import Flask, request, jsonify, render_template
from flask_mysqldb import MySQL
from preprocessing import preprocess_text
from similarity import calculate_similarity
from detection import detect_plagiarism
from database import fetch_documents
from sklearn.feature_extraction.text import TfidfVectorizer

app = Flask(__name__, template_folder='../templates', static_folder='../static')


# MySQL configurations
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = '9900'
app.config['MYSQL_DB'] = 'plagiarism_db'

mysql = MySQL(app)

@app.route('/')
def home():
    return render_template('index.html')  # Home page to select detection type

@app.route('/db_detection', methods=['GET', 'POST'])
def db_detection():
    if request.method == 'POST':
        user_text = request.form['text']
        db_texts = fetch_documents(mysql)
        results =detect_plagiarism(user_text, db_texts)
        
        return render_template('result.html', results=results, detection_type='database')
    return render_template('db_detection.html')

@app.route('/direct_comparison', methods=['GET', 'POST'])
def direct_comparison():
    if request.method == 'POST':
        text1 = request.form['text1']
        text2 = request.form['text2']
        processed_text1 = preprocess_text(text1)
        processed_text2 = preprocess_text(text2)

        vectorizer = TfidfVectorizer()
        tfidf_matrix = vectorizer.fit_transform([processed_text1, processed_text2])
        similarity_score = (calculate_similarity(tfidf_matrix[0].toarray()[0], tfidf_matrix[1].toarray()[0]))*100        
        return render_template('result.html', similarity_score=similarity_score, detection_type='direct')
    return render_template('direct_comparison.html')


if __name__ == '__main__':
    app.run(debug=True)
