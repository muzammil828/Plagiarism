from preprocessing import preprocess_text
from similarity import calculate_similarity
from sklearn.feature_extraction.text import TfidfVectorizer

def detect_plagiarism(user_text, db_texts):
    # Preprocess user text
    processed_user_text = preprocess_text(user_text)
    processed_db_texts = [preprocess_text(text) for text in db_texts]

    # Vectorize texts
    vectorizer = TfidfVectorizer()
    all_texts = [processed_user_text] + processed_db_texts
    tfidf_matrix = vectorizer.fit_transform(all_texts)

    # Calculate similarities
    results = []
    user_vector = tfidf_matrix[0].toarray()[0]  # User text vector
    for i in range(1, tfidf_matrix.shape[0]):
        db_vector = tfidf_matrix[i].toarray()[0]  # DB text vector
        similarity_score = calculate_similarity(user_vector, db_vector)
        results.append((db_texts[i-1], similarity_score))  # i-1 for corresponding DB text
    
    return results
