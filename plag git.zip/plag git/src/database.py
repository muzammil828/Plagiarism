def fetch_documents(mysql):
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT text FROM documents")  
    documents = cursor.fetchall()
    cursor.close()
    return [doc[0] for doc in documents]
